<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained('provider_branches')->onDelete('cascade');
            $table->timestamps();
            $table->softDeletes();
            $table->index('branch_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('services');
    }
};
